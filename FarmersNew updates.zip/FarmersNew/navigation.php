<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navigation Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <style>
    body {
    background-color: #f8f9fa; /* Light gray background */
    }
    .card {
            border: 2px solid #007bff; /* new primary color blue */
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3; /* darken on hover */
             border-color: #0056b3;
        }
        .nav-link.active {
            background-color: #007bff;
            color: white;
        }

      .custom-select {
        width: 250px;
      }
    </style>

</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h1 class="card-title text-center">Navigation</h1>
                        <div class="mt-4 text-center">
                        <label for="navigationSelect" class="form-label">Select a Page:</label>
                            <select id="navigationSelect" class="form-select custom-select">
                                <option value="index.php">Customer Login & Registration</option>
                                <option value="vendor_index.php">Vendor Login & Registration</option>
                            </select>
                            <button onclick="navigateToPage()" class="btn btn-primary mt-3">Go</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function navigateToPage() {
            var selectedPage = document.getElementById("navigationSelect").value;
            window.location.href = selectedPage;
        }
    </script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>