<?php
session_start();
include("connect.php");

// Redirect to login if user is not logged in
if (!isset($_SESSION['email'])) {
    header("location: index.php");
    exit();
}

// Fetch user details
$email = $_SESSION['email'];
$userQuery = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
if (!$userQuery) {
    die("Error fetching user: " . mysqli_error($conn));
}

$user = mysqli_fetch_assoc($userQuery);
if (!$user) {
    die("User not found.");
}

$userId = $user['id'];

// Handle pre-order submission
if (isset($_POST['submit_pre_order'])) {
    $produceId = $_POST['produce_id'];
    $quantity = $_POST['quantity'];

    // Insert pre-order into the database
    $insertOrderQuery = "INSERT INTO orders (user_id, produce_id, quantity, order_date) 
                         VALUES ($userId, $produceId, $quantity, NOW())";
    if (mysqli_query($conn, $insertOrderQuery)) {
        echo "<script>alert('Pre-order submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error submitting pre-order: " . mysqli_error($conn) . "');</script>";
    }
}

// Handle favourite button click
if (isset($_POST['favourite'])) {
    $produceId = $_POST['produce_id'];
    $insertFavouriteQuery = "INSERT INTO favourite_produce (user_id, produce_id) 
                             VALUES ($userId, $produceId)";
    if (mysqli_query($conn, $insertFavouriteQuery)) {
        echo "<script>alert('Added to favourites!');</script>";
    } else {
        echo "<script>alert('Error adding to favourites: " . mysqli_error($conn) . "');</script>";
    }
}

// Fetch all pre-orders for the user
$ordersQuery = mysqli_query($conn, "SELECT orders.*, produce.name AS produce_name, produce.price 
                                    FROM orders 
                                    JOIN produce ON orders.produce_id = produce.id 
                                    WHERE orders.user_id = $userId");
if (!$ordersQuery) {
    die("Error fetching orders: " . mysqli_error($conn));
}

$orders = mysqli_fetch_all($ordersQuery, MYSQLI_ASSOC);

// Fetch all available produce for pre-ordering
$produceQuery = mysqli_query($conn, "SELECT * FROM produce");
if (!$produceQuery) {
    die("Error fetching produce: " . mysqli_error($conn));
}

$produce = mysqli_fetch_all($produceQuery, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pre-ordering - Farmers' Market</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-home"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="market_search.php">
                                <i class="fas fa-search"></i> Market Search
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="pre_ordering.php">
                                <i class="fas fa-cart-plus"></i> Pre-ordering
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="vendor_tracking.php">
                                <i class="fas fa-store"></i> Vendor Tracking
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="community_reviews.php">
                                <i class="fas fa-comments"></i> Community Reviews
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Pre-ordering</h1>
                </div>

                <!-- Pre-order Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Pre-order Items</h5>
                        <form method="post" action="">
                            <div class="form-group">
                                <label for="produceSelect">Select Product</label>
                                <select class="form-control" id="produceSelect" name="produce_id" required>
                                    <?php foreach ($produce as $item): ?>
                                        <option value="<?php echo $item['id']; ?>">
                                            <?php echo $item['name']; ?> - $<?php echo $item['price']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="quantity">Quantity</label>
                                <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
                            </div>
                            <button type="submit" name="submit_pre_order" class="btn btn-primary mt-3">Submit Pre-order</button>
                        </form>
                    </div>
                </div>

                <!-- Recent Pre-orders -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Recent Pre-orders</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Total Price</th>
                                    <th>Order Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td><?php echo $order['id']; ?></td>
                                        <td><?php echo $order['produce_name']; ?></td>
                                        <td><?php echo $order['quantity']; ?></td>
                                        <td>$<?php echo $order['quantity'] * $order['price']; ?></td>
                                        <td><?php echo $order['order_date']; ?></td>
                                        <td>
                                            <form method="post" action="" style="display:inline;">
                                                <input type="hidden" name="produce_id" value="<?php echo $order['produce_id']; ?>">
                                                <button type="submit" name="favourite" class="btn btn-sm btn-warning">
                                                    <i class="fas fa-star"></i> Favourite
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>